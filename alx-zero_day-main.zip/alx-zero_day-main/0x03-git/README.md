yet another message from me to u
