hello fellow alx students this is the ****first alx project**** alx-pre_course
i am happy to be here
